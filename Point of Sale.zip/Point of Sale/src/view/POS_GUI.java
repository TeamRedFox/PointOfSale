package view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import controller.POS;
import model.InvalidUsernameOrPasswordException;

import model.User;

//should GUI have a user or should matchmaker???
//
//
//
//
//
public class POS_GUI extends JFrame {
	
	//instance variables
	private POS website;
	private static final int MIN_WIDTH = 425;
	private static final int MIN_HEIGHT = 425;
		
	//component variables
	private ProfilePanel profilePanel;
	private LoginPanel loginPanel;
	
	CardLayout card = new CardLayout();
	JPanel c = new JPanel();
	
	//Constructor
	public POS_GUI(POS website) {
		super("POS");
		this.website = website;
		
		loginPanel = new LoginPanel();
				
		setUpLayout();
		startScreen();
		addListeners();
	}
	
	public void setUpLayout() {
		c.setLayout(card);
		this.add(c);
		c.add(loginPanel, "login");
		card.show(c, "login");
	}
	
	//sets screen upon start up
	public void startScreen() {
		this.setMinimumSize(new Dimension(MIN_WIDTH, MIN_HEIGHT));
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	
	//reformats the GUI after panels are switched
	public void reformatScreen() {
		this.setResizable(false);
		this.pack();
		this.setLocationRelativeTo(null);
	}
	
	//can add actionlisteners later when needed instead of when class is constructed
	public void addListeners() {
		loginPanel.getSignInBtn().addActionListener(signIn);
		//profilePanel.getLogOutBtn().addActionListener(logOut);
	}
	
	public void setFrameTitle(String title) {
		this.setTitle(title);
	}
	//Creating ActionListeners here
	
	//sign in
	ActionListener signIn = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String username = loginPanel.getUsernameTxt().getText();
			String password = new String(loginPanel.getPasswordTxt().getPassword());
			try {
				website.setCurrentUser(website.login(username, password));
				loginPanel.getPasswordTxt().setText("");
				setFrameTitle(username);
				profilePanel = new ProfilePanel(website.getCurrentUser());
				profilePanel.getLogOutBtn().addActionListener(logOut);
				c.add("profile", profilePanel);
				card.show(c, "profile");
				reformatScreen();
			}
			catch (InvalidUsernameOrPasswordException ex) {
				loginPanel.getPasswordTxt().setText("");
				loginPanel.getErrorLbl().setText(ex.getErrorMessage());
				loginPanel.getErrorLbl().setHorizontalAlignment(JLabel.CENTER);
				loginPanel.getErrorLbl().setForeground(Color.RED);
			}
		}
	};
	
	ActionListener logOut = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			card.show(c,"login");
			setFrameTitle("POS");
			card.removeLayoutComponent(profilePanel);
			c.remove(profilePanel);
			
			loginPanel.getErrorLbl().setText("");
			reformatScreen();
		}
	};
	
	
	
	
}
