package model;

public interface Taxable {
	public double taxRate = 0.0; // Default NJ Tax rate?
}
